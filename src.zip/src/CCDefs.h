// CCDefs.h — DEPRECATED — forwarding to ParamDefs.h
// This file exists only for backward compatibility during migration.
// All new code should #include "ParamDefs.h" directly.
#pragma once
#include "ParamDefs.h"

// Re-export namespace CC at global scope so existing code
// like `CC::OSC1_WAVE` continues to resolve.
using namespace ParamDefs;