#pragma once
/*
 * PatchSchema.h
 * -------------
 * Defines which CCs are captured/restored by patches.
 * This intentionally does NOT depend on any UI layout.
 *
 * IMPORTANT: Every CC that affects audible output MUST be listed here.
 * If a CC is missing, preset load inherits stale state from the previous
 * patch — the root cause of noise bursts when switching presets.
 *
 * When adding a new CC to SynthEngine, add it here too.
 */

#include <Arduino.h>
#include "ParamDefs.h"

namespace PatchSchema {

static constexpr uint8_t kPatchableCCs[] = {

    // ---- Oscillator waveforms ----
    CC::OSC1_WAVE, CC::OSC2_WAVE,

    // ---- Oscillator pitch ----
    CC::OSC1_PITCH_OFFSET, CC::OSC2_PITCH_OFFSET,
    CC::OSC1_FINE_TUNE,    CC::OSC2_FINE_TUNE,
    CC::OSC1_DETUNE,       CC::OSC2_DETUNE,

    // ---- Oscillator mix ----
    CC::OSC_MIX_BALANCE,
    CC::OSC1_MIX, CC::OSC2_MIX,
    CC::SUB_MIX,  CC::NOISE_MIX,

    // ---- Supersaw ----
    CC::SUPERSAW1_DETUNE, CC::SUPERSAW1_MIX,
    CC::SUPERSAW2_DETUNE, CC::SUPERSAW2_MIX,

    // ---- Oscillator feedback ----
    CC::OSC1_FEEDBACK_AMOUNT, CC::OSC2_FEEDBACK_AMOUNT,
    CC::OSC1_FEEDBACK_MIX,    CC::OSC2_FEEDBACK_MIX,

    // ---- Filter core ----
    CC::FILTER_CUTOFF, CC::FILTER_RESONANCE,
    CC::FILTER_ENV_AMOUNT, CC::FILTER_KEY_TRACK,
    CC::FILTER_OCTAVE_CONTROL,

    // ---- Filter topology ----
    CC::FILTER_ENGINE, CC::FILTER_MODE, CC::VA_FILTER_TYPE,
    CC::FILTER_OBXA_XPANDER_MODE,
    CC::FILTER_OBXA_MULTIMODE, CC::FILTER_OBXA_RES_MOD_DEPTH,

    // ---- Amp envelope ----
    CC::AMP_ATTACK, CC::AMP_DECAY, CC::AMP_SUSTAIN, CC::AMP_RELEASE,

    // ---- Filter envelope ----
    CC::FILTER_ENV_ATTACK, CC::FILTER_ENV_DECAY,
    CC::FILTER_ENV_SUSTAIN, CC::FILTER_ENV_RELEASE,

    // ---- LFO1 ----
    CC::LFO1_FREQ, CC::LFO1_DEPTH, CC::LFO1_DESTINATION, CC::LFO1_WAVEFORM,
    CC::LFO1_PITCH_DEPTH, CC::LFO1_FILTER_DEPTH, CC::LFO1_PWM_DEPTH, CC::LFO1_AMP_DEPTH,
    CC::LFO1_DELAY,

    // ---- LFO2 ----
    CC::LFO2_FREQ, CC::LFO2_DEPTH, CC::LFO2_DESTINATION, CC::LFO2_WAVEFORM,
    CC::LFO2_PITCH_DEPTH, CC::LFO2_FILTER_DEPTH, CC::LFO2_PWM_DEPTH, CC::LFO2_AMP_DEPTH,
    CC::LFO2_DELAY,

    // ---- Pitch envelope ----
    CC::PITCH_ENV_ATTACK, CC::PITCH_ENV_DECAY,
    CC::PITCH_ENV_SUSTAIN, CC::PITCH_ENV_RELEASE,
    CC::PITCH_ENV_DEPTH,

    // ---- Velocity sensitivity ----
    CC::VELOCITY_AMP_SENS, CC::VELOCITY_FILTER_SENS, CC::VELOCITY_ENV_SENS,

    // ---- FX: Tone / Drive ----
    CC::FX_BASS_GAIN, CC::FX_TREBLE_GAIN, CC::FX_DRIVE,

    // ---- FX: Modulation (chorus/flanger/phaser) ----
    CC::FX_MOD_EFFECT, CC::FX_MOD_MIX, CC::FX_MOD_RATE, CC::FX_MOD_FEEDBACK,

    // ---- FX: Delay ----
    CC::FX_JPFX_DELAY_EFFECT, CC::FX_JPFX_DELAY_MIX,
    CC::FX_JPFX_DELAY_FEEDBACK, CC::FX_JPFX_DELAY_TIME,

    // ---- FX: Reverb ----
    //   Reverb CCs have moved to Performance scope (Phase 3 GlobalFX).
    //   They are serialised per-Performance, not per-Patch. Removing them
    //   from kPatchableCCs prevents patch files from bloating with
    //   meaningless per-patch reverb state.
    //   (Previous list: FX_REVERB_SIZE, FX_REVERB_DAMP, FX_REVERB_LODAMP,
    //   FX_REVERB_MIX, FX_REVERB_BYPASS.)

    // ---- FX: Output mix ----
    CC::FX_DRY_MIX, CC::FX_JPFX_MIX,

    // ---- Glide / global ----
    CC::GLIDE_ENABLE, CC::GLIDE_TIME,
    CC::AMP_MOD_FIXED_LEVEL,
    CC::POLY_MODE, CC::UNISON_DETUNE,

    // ---- Ring / DC ----
    CC::RING1_MIX, CC::RING2_MIX,
    CC::OSC1_FREQ_DC, CC::OSC1_SHAPE_DC,
    CC::OSC2_FREQ_DC, CC::OSC2_SHAPE_DC,

    // ---- Cross Modulation / Sync ----
    CC::OSC_CROSS_MOD_DEPTH, CC::OSC_SYNC_ENABLE,

    // ---- Pitch Bend ----
    CC::PITCH_BEND_RANGE,

    // ---- Extended Reverb (Performance-scope on firmware, but needed ----
    // ---- here so patch save/load round-trips correctly when reverb  ----
    // ---- settings are bundled with a patch export.)                  ----
    CC::FX_REVERB_SHIMMER, CC::FX_REVERB_FREEZE,
    CC::FX_REVERB_LOWPASS, CC::FX_REVERB_HIPASS,

    // ---- Arbitrary Waveforms ----
    CC::OSC1_ARB_BANK, CC::OSC2_ARB_BANK,
    CC::OSC1_ARB_INDEX, CC::OSC2_ARB_INDEX,
};

static constexpr int kPatchableCount =
    sizeof(kPatchableCCs) / sizeof(kPatchableCCs[0]);

} // namespace PatchSchema
